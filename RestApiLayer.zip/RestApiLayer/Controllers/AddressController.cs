using CoreWCFService1.IServices; // Adjust the namespace based on your service reference
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using CoreWCFService1.Models;

namespace CoreWCFService1.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AddressController : ControllerBase
    {
        private readonly IAddressService _addressService;

        public AddressController(IAddressService addressService)
        {
            _addressService = addressService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Address>>> GetAddresses()
        {
            try
            {
                var addresses = await _addressService.GetAddresses();
                return Ok(addresses);
            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetAddressById(string id)
        {
            try
            {
                var address = await _addressService.GetAddressById(id);
                if (address == null)
                {
                    return NotFound();
                }
                return Ok(address);
            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPost]
        public async Task<IActionResult> AddAddress([FromBody] Address address)
        {
            if (address == null)
            {
                return BadRequest("Address is null");
            }

            try
            {
                await _addressService.AddAddress(address);
                return CreatedAtAction(nameof(GetAddressById), new { id = address.AddressID }, address);
            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAddress(string id, [FromBody] Address address)
        {
            if (address == null || id != address.AddressID.ToString())
            {
                return BadRequest("Address data is invalid");
            }

            try
            {
                await _addressService.UpdateAddress(id, address);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                return StatusCode(500, "Internal server error");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAddress(string id)
        {
            try
            {
                await _addressService.DeleteAddress(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                // Log the exception (ex)
                return StatusCode(500, "Internal server error");
            }
        }
    }
}
