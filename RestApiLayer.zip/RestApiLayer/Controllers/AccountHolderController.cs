using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using CoreWCFService1.Models;
using CoreWCFService1.IServices;

namespace CoreWCFService1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountHolderController : ControllerBase
    {
        private readonly IAccountHolderService _accountHolderService;

        public AccountHolderController(IAccountHolderService accountHolderService)
        {
            _accountHolderService = accountHolderService;
        }

        // GET: api/AccountHolder
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AccountHolder>>> GetAccountHolders()
        {
            var accountHolders = await _accountHolderService.GetAccountHoldersAsync();
            return Ok(accountHolders);
        }

        // GET: api/AccountHolder/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AccountHolder>> GetAccountHolder(int id)
        {
            var accountHolder = await _accountHolderService.GetAccountHolderAsync(id);

            if (accountHolder == null)
            {
                return NotFound();
            }

            return Ok(accountHolder);
        }

        // POST: api/AccountHolder
        [HttpPost]
        public async Task<ActionResult> AddAccountHolder(AccountHolder accountHolder)
        {
            await _accountHolderService.AddAccountHolderAsync(accountHolder);
            return CreatedAtAction(nameof(GetAccountHolder), new { id = accountHolder.AccHID }, accountHolder);
        }

        // PUT: api/AccountHolder/5
        [HttpPut("{id}")]
        public async Task<ActionResult> UpdateAccountHolder(int id, AccountHolder accountHolder)
        {
            if (id != accountHolder.AccHID)
            {
                return BadRequest();
            }

            await _accountHolderService.UpdateAccountHolderAsync(accountHolder);

            return NoContent();
        }

        // DELETE: api/AccountHolder/5
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAccountHolder(int id)
        {
            var accountHolder = await _accountHolderService.GetAccountHolderAsync(id);

            if (accountHolder == null)
            {
                return NotFound();
            }

            await _accountHolderService.DeleteAccountHolderAsync(id);

            return NoContent();
        }
    }
}
