﻿using System.Collections.Generic;
using System.ServiceModel;
using System.Threading.Tasks;
using CoreWCFService1.Models;

namespace CoreWCFService1.IServices
{
   [CoreWCF.ServiceContract]
public interface IAddressService
{
    [CoreWCF.OperationContract]
    Task<IEnumerable<Address>> GetAddresses();

    [CoreWCF.OperationContract]
    Task<Address> GetAddressById(string id);

    [CoreWCF.OperationContract]
    Task AddAddress(Address address);

    [CoreWCF.OperationContract]
    Task UpdateAddress(string id, Address address);

    [CoreWCF.OperationContract]
    Task DeleteAddress(string id);
}

}
