﻿
using CoreWCF;
using CoreWCF.Channels;
using CoreWCF.Description;
using CoreWCFService1.DataAccessLayer;
using CoreWCFService1.IServices;
using CoreWCFService1.Models;
using CoreWCFService1.ServiceReference;
using CoreWCFService1.ServiceReference2;
using Microsoft.Extensions.DependencyInjection;
using ServiceReference1;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container
builder.Services.AddServiceModelServices();
builder.Services.AddServiceModelMetadata();
builder.Services.AddSingleton<IServiceBehavior, UseRequestHeadersForMetadataAddressBehavior>();



builder.Services.AddSingleton<CoreWCFService1.ServiceReference2.IAccountHolderService>(sp =>
{
    // Define endpoint configuration if necessary
    var endpointConfiguration = CoreWCFService1.ServiceReference2.AccountHolderServiceClient.EndpointConfiguration.BasicHttpBinding_IAccountHolderService;
    
    // Define the address for the service
    var address = "https://localhost:7294/AccountHolderService.svc";
    
    // Create and return the client with the endpoint configuration and address
    return new CoreWCFService1.ServiceReference2.AccountHolderServiceClient(endpointConfiguration, address);
});


builder.Services.AddSingleton<CoreWCFService1.ServiceReference3.IAddressService>(sp =>
{
    // Define endpoint configuration if necessary
    var endpointConfiguration = CoreWCFService1.ServiceReference3.AddressServiceClient.EndpointConfiguration.BasicHttpBinding_IAddressService;
    
    // Define the address for the service
    var address = "https://localhost:7294/AddressService.svc";
    
    // Create and return the client with the endpoint configuration and address
    return new CoreWCFService1.ServiceReference3.AddressServiceClient(endpointConfiguration, address);
});


builder.Services.AddSingleton<CoreWCFService1.ServiceReference4.ITransactionService>(sp =>
{
    // Define endpoint configuration if necessary
    var endpointConfiguration = CoreWCFService1.ServiceReference4.TransactionServiceClient.EndpointConfiguration.BasicHttpBinding_ITransactionService;
    
    // Define the address for the service
    var address = "https://localhost:7294/TransactionService.svc";
    
    // Create and return the client with the endpoint configuration and address
    return new CoreWCFService1.ServiceReference4.TransactionServiceClient(endpointConfiguration, address);
});





// Register LookupServiceClient with DI
builder.Services.AddSingleton<CoreWCFService1.ServiceReference.ILookupService>(sp =>
{
    var endpointAddress = new EndpointAddress("https://localhost:7294/LookupService.svc");
    var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport)
    {
        MaxBufferSize = int.MaxValue,
        MaxReceivedMessageSize = int.MaxValue,
        ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
    };

    return new LookupServiceClient(binding, endpointAddress);
});

// Register AccountServiceClient with DI
builder.Services.AddSingleton<ServiceReference1.IAccountService>(sp =>
{
    var endpointAddress = new EndpointAddress("https://localhost:7294/AccountService.svc");
    var binding = new BasicHttpBinding(BasicHttpSecurityMode.Transport)
    {
        MaxBufferSize = int.MaxValue,
        MaxReceivedMessageSize = int.MaxValue,
        ReaderQuotas = System.Xml.XmlDictionaryReaderQuotas.Max,
    };

    return new AccountServiceClient(binding, endpointAddress);
});



var app = builder.Build();

// Configure WCF services and endpoints
app.UseServiceModel(serviceBuilder =>
{
    // Configure LookupService
    serviceBuilder.AddService<LookupService>();
    serviceBuilder.AddServiceEndpoint<LookupService, CoreWCFService1.IServices.ILookupService>(
        new BasicHttpBinding(BasicHttpSecurityMode.Transport),
        "/LookupService.svc"
    );

    // Configure AccountHolderService
    serviceBuilder.AddService<AccountHolderService>();
    serviceBuilder.AddServiceEndpoint<AccountHolderService, CoreWCFService1.IServices.IAccountHolderService>(
        new BasicHttpBinding(BasicHttpSecurityMode.Transport),
        "/AccountHolderService.svc"
    );

    // Configure TransactionService
    serviceBuilder.AddService<TransactionService>();
    serviceBuilder.AddServiceEndpoint<TransactionService, ITransactionService>(
        new BasicHttpBinding(BasicHttpSecurityMode.Transport),
        "/TransactionService.svc"
    );

    // Configure AccountService
    serviceBuilder.AddService<AccountService>();
    serviceBuilder.AddServiceEndpoint<AccountService, CoreWCFService1.IServices.IAccountService>(
        new BasicHttpBinding(BasicHttpSecurityMode.Transport),
        "/AccountService.svc"
    );

    // Configure AddressService
    serviceBuilder.AddService<AddressService>();
    serviceBuilder.AddServiceEndpoint<AddressService, IAddressService>(
        new BasicHttpBinding(BasicHttpSecurityMode.Transport),
        "/AddressService.svc"
    );

    // Enable metadata for all services
    ConfigureServiceMetadata<LookupService>(serviceBuilder);
    ConfigureServiceMetadata<AccountHolderService>(serviceBuilder);
    ConfigureServiceMetadata<TransactionService>(serviceBuilder);
    ConfigureServiceMetadata<AccountService>(serviceBuilder);
    ConfigureServiceMetadata<AddressService>(serviceBuilder);
});

app.Run();

// Helper method to configure metadata
static void ConfigureServiceMetadata<TService>(IServiceBuilder serviceBuilder)
    where TService : class
{
    serviceBuilder.ConfigureServiceHostBase<TService>(serviceHost =>
    {
        var serviceMetadataBehavior = serviceHost.Description.Behaviors.Find<ServiceMetadataBehavior>();
        if (serviceMetadataBehavior != null)
        {
            serviceMetadataBehavior.HttpsGetEnabled = true;
            serviceMetadataBehavior.HttpGetEnabled = true; // Optional, depending on your requirements
        }
    });
}
